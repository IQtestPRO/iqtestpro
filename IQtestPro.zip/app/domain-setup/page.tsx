import { DomainVerification } from "@/components/domain-verification"

export default function DomainSetupPage() {
  return <DomainVerification />
}
