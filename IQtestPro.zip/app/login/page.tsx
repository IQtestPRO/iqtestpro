"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { useToast } from "@/components/ui/use-toast"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function LoginPage() {
  const [isLogin, setIsLogin] = useState(true)
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const router = useRouter()
  const { toast } = useToast()

  const handleLogin = async () => {
    try {
      const response = await fetch("/api/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, password }),
      })

      const data = await response.json()

      if (data.success) {
        toast({
          title: "Login realizado com sucesso!",
          description: "Redirecionando para o ranking...",
        })
        setTimeout(() => {
          router.push("/ranking")
        }, 1500)
      } else {
        toast({
          variant: "destructive",
          title: "Erro ao realizar login",
          description: data.message || "Credenciais inválidas.",
        })
      }
    } catch (error) {
      console.error("Erro durante o login:", error)
      toast({
        variant: "destructive",
        title: "Erro ao realizar login",
        description: "Ocorreu um erro inesperado.",
      })
    }
  }

  const handleRegister = async () => {
    try {
      const response = await fetch("/api/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, password }),
      })

      const data = await response.json()

      if (data.success) {
        toast({
          title: "Conta criada com sucesso!",
          description: "Redirecionando para o ranking...",
        })
        setTimeout(() => {
          router.push("/ranking")
        }, 1500)
      } else {
        toast({
          variant: "destructive",
          title: "Erro ao criar conta",
          description: data.message || "Ocorreu um erro.",
        })
      }
    } catch (error) {
      console.error("Erro durante o registro:", error)
      toast({
        variant: "destructive",
        title: "Erro ao criar conta",
        description: "Ocorreu um erro inesperado.",
      })
    }
  }

  return (
    <div className="flex justify-center items-center h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50 dark:from-slate-900 dark:via-slate-800 dark:to-blue-900/20">
      <Card className="w-96">
        <CardHeader>
          <CardTitle className="text-center">{isLogin ? "Login" : "Register"}</CardTitle>
        </CardHeader>
        <CardContent>
          <form
            onSubmit={(e) => {
              e.preventDefault()
              isLogin ? handleLogin() : handleRegister()
            }}
          >
            <div className="grid gap-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  placeholder="Digite seu email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  placeholder="Digite sua senha"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>
              <Button type="submit" className="w-full">
                {isLogin ? "Login" : "Register"}
              </Button>
            </div>
          </form>
          <div className="mt-4 text-center">
            <Button variant="link" onClick={() => setIsLogin(!isLogin)}>
              {isLogin ? "Não tem uma conta? Registre-se" : "Já tem uma conta? Faça login"}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
