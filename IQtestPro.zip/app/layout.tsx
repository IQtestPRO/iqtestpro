import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import "../styles/mobile-payment-fix.css"
import "../styles/mobile-first-optimized.css"
import { ThemeProvider } from "@/components/theme-provider"
import Navigation from "@/components/navigation-revamp"
import FooterRevamp from "@/components/footer-revamp"
import { PaymentProvider } from "@/contexts/payment-context"
import { AuthProvider } from "@/contexts/auth-context"
import { MobileOptimizedPayment } from "@/components/mobile-optimized-payment"
import { Toaster } from "@/components/ui/toaster"
import { ErrorBoundary } from "@/components/error-boundary"
import NeuralBackground from "@/components/neural-background"
import "../styles/neural-background.css"
import Analytics from "@/components/analytics"
import { Suspense } from "react"
import { ThemePersistence } from "@/components/theme-persistence"
import { DynamicBackground } from "@/components/dynamic-background"
import "../styles/dynamic-background.css"

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
  preload: true,
  fallback: ["system-ui", "arial"],
})

export const metadata: Metadata = {
  title: "IQ Pro - Teste de QI Online Profissional e Científico",
  description:
    "Descubra seu QI com testes validados cientificamente. Análises detalhadas, certificado oficial e comparação global. Comece agora e desvende seu potencial.",
  keywords:
    "teste de qi, qi online, teste de inteligência, qi profissional, certificado qi, psicométrico, avaliação cognitiva, inteligência fluida, raciocínio lógico, raciocínio espacial",
  authors: [{ name: "IQ Pro" }],
  creator: "IQ Pro Team",
  publisher: "IQ Pro Platform",
  metadataBase: new URL("https://iqtestpro.online"),
  alternates: {
    canonical: "https://iqtestpro.online/",
  },
  openGraph: {
    title: "IQ Pro - Teste de QI Online Profissional e Científico",
    description:
      "Descubra seu QI com testes validados cientificamente. Análises detalhadas, certificado oficial e comparação global.",
    url: "https://iqtestpro.online",
    siteName: "IQ Pro",
    images: [
      {
        url: "/og-image-iqpro.png",
        width: 1200,
        height: 630,
        alt: "IQ Pro - Teste de QI Online",
      },
    ],
    locale: "pt_BR",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "IQ Pro - Teste de QI Online Profissional e Científico",
    description:
      "Descubra seu QI com testes validados cientificamente. Análises detalhadas, certificado oficial e comparação global.",
    images: ["/twitter-image-iqpro.png"],
    creator: "@iqpro_official",
  },
  icons: {
    icon: "/favicon.ico",
    shortcut: "/favicon-16x16.png",
    apple: "/apple-touch-icon.png",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  manifest: "/site.webmanifest",
  verification: {
    google: "YOUR_GOOGLE_VERIFICATION_CODE",
  },
  generator: "v0.dev",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="pt-BR" suppressHydrationWarning className={inter.variable}>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link rel="dns-prefetch" href="https://images.unsplash.com" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=5, viewport-fit=cover" />
        <meta name="theme-color" content="#3b82f6" media="(prefers-color-scheme: light)" />
        <meta name="theme-color" content="#1e40af" media="(prefers-color-scheme: dark)" />
        <meta name="color-scheme" content="light dark" />
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="default" />
        <meta name="format-detection" content="telephone=no" />
        <script
          dangerouslySetInnerHTML={{
            __html: `
      (function() {
        try {
          const theme = localStorage.getItem('iqpro-theme') || 'dark';
          const isDark = theme === 'dark' || (theme === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);
          
          if (isDark) {
            document.documentElement.classList.add('dark');
            document.documentElement.setAttribute('data-theme', 'dark');
            document.documentElement.style.backgroundColor = 'hsl(222.2, 84%, 4.9%)';
          } else {
            document.documentElement.classList.remove('dark');
            document.documentElement.setAttribute('data-theme', 'light');
            document.documentElement.style.backgroundColor = 'hsl(0, 0%, 100%)';
          }
        } catch (_) {
          // Fallback to dark theme if there's an error
          document.documentElement.classList.add('dark');
          document.documentElement.setAttribute('data-theme', 'dark');
          document.documentElement.style.backgroundColor = 'hsl(222.2, 84%, 4.9%)';
        }
      })();
    `,
          }}
        />
      </head>
      <body className={`font-sans bg-background text-foreground antialiased page-transition theme-transition`}>
        <DynamicBackground />
        <NeuralBackground />
        <ErrorBoundary>
          <Suspense fallback={null}>
            <ThemeProvider>
              <ThemePersistence />
              <AuthProvider>
                <PaymentProvider>
                  <div className="flex flex-col min-h-screen relative">
                    <Navigation />
                    <main className="flex-grow">{children}</main>
                    <FooterRevamp />
                  </div>
                  <MobileOptimizedPayment />
                  <Toaster />
                  <Analytics />
                </PaymentProvider>
              </AuthProvider>
            </ThemeProvider>
          </Suspense>
        </ErrorBoundary>
      </body>
    </html>
  )
}
