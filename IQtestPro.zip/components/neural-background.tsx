"use client"

export function NeuralBackground() {
  return (
    <>
      <div className="neural-background">
        <div className="neural-connections"></div>
        <div className="brain-shapes"></div>
      </div>
    </>
  )
}

export default NeuralBackground
